package com.consumer.service.entity;

import java.util.ArrayList;
import java.util.List;

public class ProductEntityList {

	private List<ProductEntity> productEntityList;
	 
    public ProductEntityList() {
    	productEntityList = new ArrayList<>();
    }

	public List<ProductEntity> getProductEntityList() {
		return productEntityList;
	}

	public void setProductEntityList(List<ProductEntity> productEntityList) {
		this.productEntityList = productEntityList;
	}
 
    
    
    
    
}
